// // 2. Realizar una función que imprima los números impares existentes hasta el número
// // indicado como parámetro de entrada.
// // La cabecera de la función tendrá el siguiente aspecto: function evenNumbers(num)



function evenNumbers (num : number) {
    let cuenta : number[] = []
    for (let i = 0; i <= num; i++){
        if ((i % 2) !== 0){
            cuenta.push(i);
        } 
    } return cuenta;
}


console.log(evenNumbers(10));






// // 3. Realizar una función que como parámetro de entrada reciba un array y como salida
// // devuelva el array revertido. No se puede utilizar el método revert de la clase array
// // La cabecera de la función tendrá el siguiente aspecto: function myRevert(myArr)


let numeros = [4, 27, 7, 100];




function myRevert(numeros : number[]) {
    let salida : number[] = []
    for (let i = numeros.length - 1; i >= 0; i--) {
      salida.push(numeros[i]);
    }
    return salida;
}

console.log(myRevert(numeros));






// // 4. Realizar una función que reciba como parámetro un array de strings que contenga
// // nombres de colores y te imprima en cada caso si el color está en el arcoíris o no.
// // La cabecera de la función tendrá el siguiente aspecto: function isRainbow(colors)


let rainbow : string[] = ["rojo", "naranja", "amarillo", "verde", "azul", "violeta"];

let arrayColors : string[] = ["rojo", "rojo", "rojo"];


function isRainbow (arrayColors : string[]) {

    for (let i = 0; i <= arrayColors.length; i++){
        if (arrayColors[i] == "rojo" || arrayColors[i] == "naranja" || arrayColors[i] == "amarillo" || arrayColors[i] == "verde" || arrayColors[i] == "azul" || arrayColors[i] == "violeta"){
            return true;
        } else {
            return false;
        }
    }
}

// function isRainbow2 (arrayColors : string[]) {

//     for (colors of rainbow){
//         if ("rojo" == colors || arrayColors[i] == "naranja" || arrayColors[i] == "amarillo" || arrayColors[i] == "verde" || arrayColors[i] == "azul" || arrayColors[i] == "violeta"){
//             return true;
//         } else {
//             return false;
//         }
//     }
// }


console.log(isRainbow(arrayColors));





// // 5. Realizar una función que te devuelva la suma del numero de caracteres de las palabras
// // almacenadas en un array.
// // La cabecera de la función tendrá el siguiente aspecto: function add(myWords)

let myWorlds : string[] = ["Coche", "moto", "patin"];



function add( myWorlds:string[]) {
    let coleccion : number[] = []
    for (let i=0 ; i<=myWorlds.length; i++){
        coleccion.push( myWorlds[i].length[i] += myWorlds[i].length[i]);
    }return coleccion;
}


console.log(add(myWorlds));
