"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Contacts_1 = require("./Contacts");
var contacts = new Contacts_1.Contacts();
// console.log(contacts);
contacts.printCalendar();
