import {Person} from "./person";

let person = new Person ("Javi", 32, "Paz" );



console.log(person.printName());

console.log(person.yearOfBirth(2022));

console.log(person.setAddress("Calle"));

console.log(person.getAddress());




