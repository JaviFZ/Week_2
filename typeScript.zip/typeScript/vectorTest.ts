import {Vector} from "./vector";



let vector = new Vector(8, 10)