import {Book} from "./book";



let book : Book = new Book("El Quijote", 1734, "12314-BC123144", "Miguel de Cervantes", "Santillana");

console.log(book);

console.log(book.toString());