import {Contacts} from "./Contacts";



let contacts = new Contacts();

// console.log(contacts);

contacts.printCalendar();